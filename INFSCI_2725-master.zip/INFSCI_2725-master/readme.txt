This repository is just for the my data analytics class. 

I will delete this repository after my class is over.

Please just ignore this repository.