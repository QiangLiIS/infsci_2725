First, we convert the dat file to json file through Java

Second, we import the data into mongoDB through shell.

Third, we do the query through Python.